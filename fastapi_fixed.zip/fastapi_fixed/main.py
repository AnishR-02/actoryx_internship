from fastapi import FastAPI, Request, Form, UploadFile, File
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import pandas as pd
import io

app = FastAPI()

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Home
@app.get("/")
def home(request: Request):
    return templates.TemplateResponse(request=request, name="index.html", context={})

# Code 1: Odd or Even
@app.get("/odd-or-even")
def odd_or_even_page(request: Request):
    return templates.TemplateResponse(request=request, name="odd_or_even.html", context={})

@app.post("/odd-or-even")
def odd_or_even(request: Request, num: int = Form(...)):
    result = f"{num} is Even" if num % 2 == 0 else f"{num} is Odd"
    return templates.TemplateResponse(request=request, name="odd_or_even.html", context={"odd_even_result": result})

# Code 2: Voting Eligibility
@app.get("/voting")
def voting_page(request: Request):
    return templates.TemplateResponse(request=request, name="voting.html", context={})

@app.post("/voting")
def voting(request: Request, age: int = Form(...)):
    if age >= 18:
        result = f"Age {age} → You are eligible to vote ✅"
    else:
        result = f"Age {age} → You are not eligible to vote ❌"
    return templates.TemplateResponse(request=request, name="voting.html", context={"voting_result": result})

# Code 3: Compare Two Numbers
@app.get("/compare")
def compare_page(request: Request):
    return templates.TemplateResponse(request=request, name="compare.html", context={})

@app.post("/compare")
def compare(request: Request, num1: int = Form(...), num2: int = Form(...)):
    if num1 > num2:
        result = f"{num1} is bigger"
    elif num1 < num2:
        result = f"{num2} is bigger"
    else:
        result = f"{num1} is equal to {num2}"
    return templates.TemplateResponse(request=request, name="compare.html", context={"compare_result": result})

# Code 4: Sign Check
@app.get("/sign-check")
def sign_check_page(request: Request):
    return templates.TemplateResponse(request=request, name="sign_check.html", context={})

@app.post("/sign-check")
def sign_check(request: Request, num: int = Form(...)):
    if num > 0:
        result = f"{num} is Positive ➕"
    elif num < 0:
        result = f"{num} is Negative ➖"
    else:
        result = f"{num} is Zero"
    return templates.TemplateResponse(request=request, name="sign_check.html", context={"sign_result": result})

# Code 5: Calculator
@app.get("/calculator")
def calculator_page(request: Request):
    return templates.TemplateResponse(request=request, name="calculator.html", context={})

@app.post("/calculator")
def calculator(request: Request, num1: float = Form(...), operator: str = Form(...), num2: float = Form(...)):
    if operator == "+":
        result = f"{num1} + {num2} = {num1 + num2}"
    elif operator == "-":
        result = f"{num1} - {num2} = {num1 - num2}"
    elif operator == "*":
        result = f"{num1} * {num2} = {num1 * num2}"
    elif operator == "/":
        result = "Error: Division by zero!" if num2 == 0 else f"{num1} / {num2} = {num1 / num2}"
    else:
        result = "Invalid operator!"
    return templates.TemplateResponse(request=request, name="calculator.html", context={"calc_result": result})

# Code 6: Print 1 to 10
@app.get("/one-to-ten")
def one_to_ten(request: Request):
    numbers = list(range(1, 11))
    return templates.TemplateResponse(request=request, name="one_to_ten.html", context={"one_to_ten_result": numbers})

# Code 7: Print 1 to N
@app.get("/one-to-n")
def one_to_n_page(request: Request):
    return templates.TemplateResponse(request=request, name="one_to_n.html", context={})

@app.post("/one-to-n")
def one_to_n(request: Request, n: int = Form(...)):
    numbers = list(range(1, n + 1))
    return templates.TemplateResponse(request=request, name="one_to_n.html", context={"one_to_n_result": numbers})

# Code 8: Multiplication Table
@app.get("/multiplication-table")
def multiplication_table_page(request: Request):
    return templates.TemplateResponse(request=request, name="multiplication_table.html", context={})

@app.post("/multiplication-table")
def multiplication_table(request: Request, n: int = Form(...)):
    table = [f"{n} x {i} = {n * i}" for i in range(1, 11)]
    return templates.TemplateResponse(request=request, name="multiplication_table.html", context={"multi_table_result": table})

# Code 9: Table of 9
@app.get("/table-of-9")
def table_of_9(request: Request):
    table = [f"9 x {i} = {9 * i}" for i in range(1, 11)]
    return templates.TemplateResponse(request=request, name="table_of_9.html", context={"table9_result": table})

# Code 10: Sum of Digits
@app.get("/sum-of-digits")
def sum_of_digits_page(request: Request):
    return templates.TemplateResponse(request=request, name="sum_of_digits.html", context={})

@app.post("/sum-of-digits")
def sum_of_digits(request: Request, n: int = Form(...)):
    original = n
    total = 0
    while n > 0:
        total += n % 10
        n = n // 10
    result = f"Sum of digits of {original} = {total}"
    return templates.TemplateResponse(request=request, name="sum_of_digits.html", context={"digit_sum_result": result})

# Code 11: Factorial
@app.get("/factorial")
def factorial_page(request: Request):
    return templates.TemplateResponse(request=request, name="factorial.html", context={})

@app.post("/factorial")
def factorial(request: Request, n: int = Form(...)):
    fact = 1
    for i in range(1, n + 1):
        fact *= i
    result = f"{n}! = {fact}"
    return templates.TemplateResponse(request=request, name="factorial.html", context={"factorial_result": result})

# Code 12: Factors
@app.get("/factors")
def factors_page(request: Request):
    return templates.TemplateResponse(request=request, name="factors.html", context={})

@app.post("/factors")
def factors(request: Request, n: int = Form(...)):
    result = [i for i in range(1, n + 1) if n % i == 0]
    return templates.TemplateResponse(request=request, name="factors.html", context={"factors_result": result})

# Code 13: Prime Check
@app.get("/prime-check")
def prime_check_page(request: Request):
    return templates.TemplateResponse(request=request, name="prime_check.html", context={})

@app.post("/prime-check")
def prime_check(request: Request, n: int = Form(...)):
    if n < 2:
        result = f"{n} is not a prime number"
    else:
        is_prime = all(n % i != 0 for i in range(2, int(n**0.5) + 1))
        result = f"{n} is a prime number ✅" if is_prime else f"{n} is not a prime number ❌"
    return templates.TemplateResponse(request=request, name="prime_check.html", context={"prime_result": result})

# Code 14: Sum of List
@app.get("/sum-of-list")
def sum_of_list_page(request: Request):
    return templates.TemplateResponse(request=request, name="sum_of_list.html", context={})

@app.post("/sum-of-list")
def sum_of_list(request: Request, numbers: str = Form(...)):
    num_list = [int(x.strip()) for x in numbers.split(",")]
    total = sum(num_list)
    result = f"Numbers: {num_list} → Sum = {total}"
    return templates.TemplateResponse(request=request, name="sum_of_list.html", context={"list_sum_result": result})

# Code 15: Grade Calculator
@app.get("/grade")
def grade_page(request: Request):
    return templates.TemplateResponse(request=request, name="grade.html", context={})

@app.post("/grade")
def grade(request: Request, maths: int = Form(...), physics: int = Form(...), chemistry: int = Form(...)):
    total = maths + physics + chemistry
    avg = total // 3
    if avg > 90: g = "A+"
    elif avg > 80: g = "A"
    elif avg > 70: g = "B"
    elif avg > 60: g = "C"
    elif avg > 50: g = "D"
    else: g = "F"
    result = f"Average: {avg} → Grade: {g}"
    return templates.TemplateResponse(request=request, name="grade.html", context={"grade_result": result})

# Code 16: Student CSV Upload
@app.get("/students")
def students_page(request: Request):
    return templates.TemplateResponse(request=request, name="students.html", context={})

@app.post("/students")
async def students(request: Request, file: UploadFile = File(...)):
    contents = await file.read()
    df = pd.read_csv(io.StringIO(contents.decode("utf-8")))
    data = df.head(10).to_dict(orient="records")
    columns = df.columns.tolist()
    return templates.TemplateResponse(request=request, name="students.html", context={"students_data": data, "students_columns": columns})
