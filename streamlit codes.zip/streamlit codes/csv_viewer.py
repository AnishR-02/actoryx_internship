import streamlit as st
import pandas as pd

st.title("CSV File Viewer 📊")

uploaded_file = st.file_uploader("Upload a CSV file", type="csv")

if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)

    st.subheader("Preview of your data:")
    st.dataframe(df.head(10))

    st.subheader("Basic Information:")
    st.info(f"Total Rows: {df.shape[0]}")
    st.info(f"Total Columns: {df.shape[1]}")
    st.info(f"Column Names: {list(df.columns)}")

    st.subheader("Summary Statistics:")
    st.write(df.describe())